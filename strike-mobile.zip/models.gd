extends RefCounted
# Простые low-poly модели из коробок: солдат, оружие, блоки карты. Всё нарисовано с нуля.

static var _mats := {}


static func mat(c: Color) -> StandardMaterial3D:
	var key := c.to_html()
	if not _mats.has(key):
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		m.roughness = 1.0
		_mats[key] = m
	return _mats[key]


static func box(parent: Node, size: Vector3, pos: Vector3, color: Color, rot_deg := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat(color)
	mi.position = pos
	mi.rotation_degrees = rot_deg
	parent.add_child(mi)
	return mi


static func cyl(parent: Node, radius: float, height: float, pos: Vector3, color: Color, rot_deg := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = 10
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = mat(color)
	mi.position = pos
	mi.rotation_degrees = rot_deg
	parent.add_child(mi)
	return mi


# Блок карты со столкновениями. Лёгкая вариация оттенка, чтобы стены не были одноцветными.
static func solid(parent: Node, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = pos
	var shape := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	shape.shape = bs
	body.add_child(shape)
	var tint := color.lightened(0.035 * float(int(absf(pos.x + pos.z)) % 3))
	box(body, size, Vector3.ZERO, tint)
	parent.add_child(body)
	return body


static func solid_cylinder(parent: Node, pos: Vector3, radius: float, height: float, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = pos
	var shape := CollisionShape3D.new()
	var cs := CylinderShape3D.new()
	cs.radius = radius
	cs.height = height
	shape.shape = cs
	body.add_child(shape)
	cyl(body, radius, height, Vector3.ZERO, color)
	cyl(body, radius + 0.02, 0.08, Vector3(0, height * 0.25, 0), color.darkened(0.3))
	cyl(body, radius + 0.02, 0.08, Vector3(0, -height * 0.25, 0), color.darkened(0.3))
	parent.add_child(body)
	return body


# Оружие смотрит стволом в -Z, начало координат у рукояти. Длина лежит в meta "len".
static func make_weapon(key: String) -> Node3D:
	var root := Node3D.new()
	var metal := Color(0.16, 0.17, 0.19)
	var dark := Color(0.09, 0.09, 0.1)
	var wood := Color(0.42, 0.28, 0.16)
	var green := Color(0.24, 0.3, 0.2)
	match key:
		"pistol":
			box(root, Vector3(0.05, 0.06, 0.22), Vector3(0, 0.03, -0.1), metal)
			box(root, Vector3(0.045, 0.11, 0.06), Vector3(0, -0.04, 0.0), dark, Vector3(12, 0, 0))
			box(root, Vector3(0.02, 0.02, 0.04), Vector3(0, 0.07, -0.19), dark)
			root.set_meta("len", 0.22)
		"smg":
			box(root, Vector3(0.06, 0.08, 0.32), Vector3(0, 0.02, -0.16), metal)
			box(root, Vector3(0.03, 0.03, 0.14), Vector3(0, 0.03, -0.39), dark)
			box(root, Vector3(0.04, 0.15, 0.05), Vector3(0, -0.08, -0.16), dark)
			box(root, Vector3(0.045, 0.1, 0.05), Vector3(0, -0.06, 0.0), dark, Vector3(10, 0, 0))
			box(root, Vector3(0.04, 0.06, 0.18), Vector3(0, 0.0, 0.15), metal)
			root.set_meta("len", 0.46)
		"rifle":
			box(root, Vector3(0.06, 0.09, 0.5), Vector3(0, 0.02, -0.25), metal)
			box(root, Vector3(0.07, 0.07, 0.25), Vector3(0, 0.01, -0.55), wood)
			box(root, Vector3(0.025, 0.025, 0.25), Vector3(0, 0.03, -0.8), dark)
			box(root, Vector3(0.05, 0.16, 0.07), Vector3(0, -0.1, -0.3), dark, Vector3(-12, 0, 0))
			box(root, Vector3(0.045, 0.1, 0.05), Vector3(0, -0.07, -0.02), dark, Vector3(10, 0, 0))
			box(root, Vector3(0.05, 0.09, 0.28), Vector3(0, 0.0, 0.18), wood)
			box(root, Vector3(0.03, 0.04, 0.06), Vector3(0, 0.085, -0.35), dark)
			root.set_meta("len", 0.92)
		"sniper":
			box(root, Vector3(0.06, 0.09, 0.6), Vector3(0, 0.02, -0.3), metal)
			box(root, Vector3(0.025, 0.025, 0.6), Vector3(0, 0.03, -0.9), dark)
			cyl(root, 0.03, 0.3, Vector3(0, 0.11, -0.35), dark, Vector3(90, 0, 0))
			box(root, Vector3(0.05, 0.1, 0.3), Vector3(0, -0.0, 0.2), green)
			box(root, Vector3(0.04, 0.1, 0.05), Vector3(0, -0.08, -0.25), dark)
			box(root, Vector3(0.045, 0.1, 0.05), Vector3(0, -0.07, -0.02), dark, Vector3(10, 0, 0))
			root.set_meta("len", 1.2)
		_:
			box(root, Vector3(0.05, 0.06, 0.22), Vector3(0, 0.03, -0.1), metal)
			root.set_meta("len", 0.22)
	return root


# Солдат ростом 1.8 м, смотрит в -Z, в руках автомат.
static func make_soldier(team_color: Color) -> Node3D:
	var root := Node3D.new()
	var skin := Color(0.85, 0.65, 0.5)
	var pants := Color(0.2, 0.22, 0.25)
	var dark := Color(0.12, 0.13, 0.14)
	box(root, Vector3(0.17, 0.8, 0.2), Vector3(-0.12, 0.4, 0), pants)
	box(root, Vector3(0.17, 0.8, 0.2), Vector3(0.12, 0.4, 0), pants)
	box(root, Vector3(0.5, 0.62, 0.3), Vector3(0, 1.1, 0), team_color)
	box(root, Vector3(0.52, 0.1, 0.32), Vector3(0, 0.82, 0), dark)
	box(root, Vector3(0.24, 0.26, 0.24), Vector3(0, 1.56, 0), skin)
	box(root, Vector3(0.3, 0.12, 0.3), Vector3(0, 1.72, 0), team_color.darkened(0.4))
	box(root, Vector3(0.12, 0.5, 0.14), Vector3(-0.32, 1.1, -0.05), team_color.darkened(0.2), Vector3(-20, 0, 0))
	box(root, Vector3(0.12, 0.5, 0.14), Vector3(0.32, 1.12, -0.12), team_color.darkened(0.2), Vector3(-45, 0, 0))
	var gun := make_weapon("rifle")
	gun.position = Vector3(0.26, 1.08, 0.05)
	root.add_child(gun)
	return root
