extends RefCounted
# Настройки игры. Хранятся в user://settings.cfg.
# quality: 0 низкая, 1 средняя, 2 высокая.

const PATH := "user://settings.cfg"

static var quality := 1
static var sensitivity := 1.0
static var loaded := false


static func load_settings() -> void:
	if loaded:
		return
	loaded = true
	var cf := ConfigFile.new()
	if cf.load(PATH) == OK:
		quality = clampi(int(cf.get_value("gfx", "quality", 1)), 0, 2)
		sensitivity = clampf(float(cf.get_value("input", "sensitivity", 1.0)), 0.5, 2.0)


static func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("gfx", "quality", quality)
	cf.set_value("input", "sensitivity", sensitivity)
	cf.save(PATH)


# Применяет качество к окну и солнцу. На телефоне важнее всего частота кадров.
static func apply(vp: Viewport, sun: DirectionalLight3D) -> void:
	Engine.max_fps = 60
	match quality:
		0:
			vp.scaling_3d_scale = 0.7
			vp.msaa_3d = Viewport.MSAA_DISABLED
			sun.shadow_enabled = false
		1:
			vp.scaling_3d_scale = 0.85
			vp.msaa_3d = Viewport.MSAA_DISABLED
			sun.shadow_enabled = true
			sun.directional_shadow_max_distance = 30.0
		_:
			vp.scaling_3d_scale = 1.0
			vp.msaa_3d = Viewport.MSAA_2X
			sun.shadow_enabled = true
			sun.directional_shadow_max_distance = 55.0
