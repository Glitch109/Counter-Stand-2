extends RefCounted
# Таблица оружия. price: цена в магазине, spread: разброс стоя, move_spread: добавка при движении и в прыжке.

const DATA = {
	"pistol": {
		"name": "Пистолет", "price": 0, "mag": 12, "reserve": 36, "damage": 24,
		"interval": 0.25, "auto": false, "spread": 0.006, "move_spread": 0.02,
		"reload": 1.4, "len": 0.3, "color": Color(0.2, 0.2, 0.22),
	},
	"smg": {
		"name": "Пистолет-пулемёт", "price": 1200, "mag": 30, "reserve": 90, "damage": 18,
		"interval": 0.07, "auto": true, "spread": 0.014, "move_spread": 0.012,
		"reload": 1.8, "len": 0.45, "color": Color(0.25, 0.25, 0.3),
	},
	"rifle": {
		"name": "Автомат", "price": 2700, "mag": 30, "reserve": 90, "damage": 28,
		"interval": 0.1, "auto": true, "spread": 0.01, "move_spread": 0.02,
		"reload": 2.2, "len": 0.7, "color": Color(0.3, 0.25, 0.2),
	},
	"sniper": {
		"name": "Снайперка", "price": 4750, "mag": 5, "reserve": 20, "damage": 90,
		"interval": 1.2, "auto": false, "spread": 0.001, "move_spread": 0.09,
		"reload": 2.8, "len": 0.95, "color": Color(0.15, 0.2, 0.15),
	},
}

const BUYABLE = ["smg", "rifle", "sniper"]
