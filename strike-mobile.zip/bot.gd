extends CharacterBody3D
# Простой бот: идёт к ближайшему врагу, обходит препятствия, стреляет с погрешностью.

const Models = preload("res://models.gd")

signal shot(from: Vector3, to: Vector3)

const SPEED := 3.8
const GRAVITY := 16.0
const SIGHT := 45.0

var team := 1
var hp := 100
var damage := 10
var alive := true
var color := Color(0.9, 0.25, 0.2)
var main_node: Node

var target: Node3D = null
var can_see := false
var think_cd := 0.0
var shoot_cd := 0.0
var react_cd := 0.0
var strafe := 1.0
var strafe_cd := 0.0
var avoid_cd := 0.0
var avoid_side := 1.0
var stuck_t := 0.0


func _ready() -> void:
	collision_layer = 2
	collision_mask = 3

	var col := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.4
	capsule.height = 1.8
	col.shape = capsule
	col.position.y = 0.9
	add_child(col)

	add_child(Models.make_soldier(color))


func _physics_process(delta: float) -> void:
	if not alive or main_node == null or not main_node.round_active:
		return

	think_cd -= delta
	shoot_cd -= delta
	react_cd -= delta
	strafe_cd -= delta
	avoid_cd -= delta

	if think_cd <= 0.0:
		think_cd = 0.25
		_think()

	var move_dir := Vector3.ZERO
	if target != null and is_instance_valid(target):
		var to := target.global_position - global_position
		to.y = 0.0
		var dist := to.length()
		var fwd := to.normalized()
		var right := fwd.cross(Vector3.UP)
		rotation.y = atan2(-fwd.x, -fwd.z)

		if strafe_cd <= 0.0:
			strafe = [-1.0, 0.0, 1.0].pick_random()
			strafe_cd = randf_range(0.6, 1.6)

		if can_see and dist < 10.0:
			move_dir = right * strafe
		else:
			move_dir = fwd + right * strafe * 0.3

		if avoid_cd > 0.0:
			move_dir = right * avoid_side
		elif _blocked(move_dir):
			avoid_cd = 1.0
			move_dir = right * avoid_side

		if can_see and react_cd <= 0.0 and shoot_cd <= 0.0 and dist < SIGHT:
			shoot_cd = randf_range(0.25, 0.45)
			_fire_at(target, dist)

	if move_dir.length() > 0.01:
		move_dir = move_dir.normalized()
	velocity.x = move_dir.x * SPEED
	velocity.z = move_dir.z * SPEED
	if is_on_floor():
		velocity.y = 0.0
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()

	# если упёрлись в стену — сменить сторону обхода
	if move_dir.length() > 0.1 and Vector2(velocity.x, velocity.z).length() < SPEED * 0.4:
		stuck_t += delta
		if stuck_t > 0.6:
			stuck_t = 0.0
			avoid_side = -avoid_side
			avoid_cd = 1.2
	else:
		stuck_t = 0.0


func _think() -> void:
	var best: Node3D = null
	var best_d := INF
	for o in main_node.get_opponents(team):
		var d: float = global_position.distance_to(o.global_position)
		if d < best_d:
			best_d = d
			best = o
	if best != target:
		react_cd = randf_range(0.25, 0.6)
	target = best
	can_see = target != null and _can_see(target)


func _can_see(t: Node3D) -> bool:
	var from := global_position + Vector3(0, 1.5, 0)
	var to := t.global_position + Vector3(0, 1.2, 0)
	var q := PhysicsRayQueryParameters3D.create(from, to)
	q.exclude = [get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	return not hit.is_empty() and hit["collider"] == t


func _blocked(dir: Vector3) -> bool:
	if dir.length() < 0.01:
		return false
	var from := global_position + Vector3(0, 0.6, 0)
	var q := PhysicsRayQueryParameters3D.create(from, from + dir.normalized() * 1.6)
	q.collision_mask = 1
	q.exclude = [get_rid()]
	return not get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func _fire_at(t: Node3D, dist: float) -> void:
	var chance := clampf(0.6 - dist * 0.014, 0.12, 0.5)
	var aim := t.global_position + Vector3(0, 1.1, 0)
	var muzzle := global_position + Vector3(0, 1.3, 0) + (aim - global_position).normalized() * 0.6
	if randf() < chance:
		t.take_damage(damage, team)
	else:
		aim += Vector3(randf_range(-1.0, 1.0), randf_range(-0.6, 0.6), randf_range(-1.0, 1.0))
	shot.emit(muzzle, aim)


func take_damage(amount: int, from_team: int) -> void:
	if not alive or from_team == team:
		return
	hp -= amount
	if hp <= 0:
		alive = false
		collision_layer = 0
		rotation.x = -PI / 2.0
		position.y += 0.4


func reset_for_round(pos: Vector3) -> void:
	alive = true
	hp = 100
	collision_layer = 2
	rotation = Vector3.ZERO
	global_position = pos
	velocity = Vector3.ZERO
	target = null
	can_see = false
	shoot_cd = 0.0
	avoid_cd = 0.0
	stuck_t = 0.0
	if team == 1:
		rotation.y = PI
