extends Node3D
# Менеджер игры: арена, раунды, HUD. Всё строится кодом, без ручных сцен.

const PlayerScript = preload("res://player.gd")
const BotScript = preload("res://bot.gd")
const TouchScript = preload("res://touch_controls.gd")

const WIN_SCORE := 8
const BETWEEN_ROUNDS := 3.5

const PLAYER_SPAWN := Vector3(0, 0.1, 17)
const ALLY_SPAWNS = [Vector3(-4, 0.1, 17), Vector3(4, 0.1, 17)]
const ENEMY_SPAWNS = [Vector3(-4, 0.1, -17), Vector3(0, 0.1, -17), Vector3(4, 0.1, -17)]

# [позиция центра, размер]
const CRATES = [
	[Vector3(0, 1, 0), Vector3(4, 2, 4)],
	[Vector3(-9, 1, -4), Vector3(3, 2, 3)],
	[Vector3(9, 1, 4), Vector3(3, 2, 3)],
	[Vector3(-12, 1.5, 8), Vector3(2, 3, 6)],
	[Vector3(12, 1.5, -8), Vector3(2, 3, 6)],
	[Vector3(-5, 0.75, -10), Vector3(2, 1.5, 2)],
	[Vector3(5, 0.75, 10), Vector3(2, 1.5, 2)],
	[Vector3(0, 1, -13), Vector3(8, 2, 1)],
	[Vector3(0, 1, 13), Vector3(8, 2, 1)],
	[Vector3(-16, 1, -2), Vector3(1, 2, 8)],
	[Vector3(16, 1, 2), Vector3(1, 2, 8)],
]

var player
var allies: Array = []
var enemies: Array = []
var round_active := false
var round_number := 0
var score := [0, 0]
var last_hp := 100

var hud: CanvasLayer
var hp_label: Label
var ammo_label: Label
var score_label: Label
var msg_label: Label
var flash_rect: ColorRect
var cross_h: ColorRect
var cross_v: ColorRect
var tracer_mat: StandardMaterial3D


func _ready() -> void:
	randomize()
	tracer_mat = StandardMaterial3D.new()
	tracer_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	tracer_mat.albedo_color = Color(1.0, 0.9, 0.4)
	_build_environment()
	_build_arena()
	_build_actors()
	_build_hud()
	_start_round()


func _process(_delta: float) -> void:
	if not round_active:
		return
	var ct_alive := 1 if player.alive else 0
	for a in allies:
		if a.alive:
			ct_alive += 1
	var t_alive := 0
	for e in enemies:
		if e.alive:
			t_alive += 1
	if t_alive == 0:
		_end_round(0)
	elif ct_alive == 0:
		_end_round(1)


# ---------- мир ----------

func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.55, 0.7, 0.9)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.75, 0.75, 0.8)
	env.ambient_light_energy = 0.8
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, 35, 0)
	sun.light_energy = 0.9
	add_child(sun)


func _add_box(pos: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = pos

	var shape := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	shape.shape = bs
	body.add_child(shape)

	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mesh.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mesh.material_override = mat
	body.add_child(mesh)

	add_child(body)


func _build_arena() -> void:
	_add_box(Vector3(0, -0.5, 0), Vector3(48, 1, 48), Color(0.76, 0.69, 0.5))
	var wall_color := Color(0.6, 0.55, 0.45)
	_add_box(Vector3(0, 2, -24), Vector3(48, 4, 1), wall_color)
	_add_box(Vector3(0, 2, 24), Vector3(48, 4, 1), wall_color)
	_add_box(Vector3(-24, 2, 0), Vector3(1, 4, 48), wall_color)
	_add_box(Vector3(24, 2, 0), Vector3(1, 4, 48), wall_color)
	var i := 0
	for c in CRATES:
		var shade := 0.45 + 0.05 * float(i % 4)
		_add_box(c[0], c[1], Color(shade + 0.1, shade, shade - 0.15))
		i += 1


func _build_actors() -> void:
	player = PlayerScript.new()
	player.shot.connect(spawn_tracer)
	player.hp_changed.connect(_on_hp_changed)
	player.ammo_changed.connect(_update_ammo)
	player.died.connect(_on_player_died)
	player.hit_enemy.connect(_on_hit_enemy)
	add_child(player)

	for i in ALLY_SPAWNS.size():
		allies.append(_make_bot(0, Color(0.2, 0.45, 0.95)))
	for i in ENEMY_SPAWNS.size():
		enemies.append(_make_bot(1, Color(0.9, 0.25, 0.2)))


func _make_bot(team: int, color: Color):
	var b = BotScript.new()
	b.team = team
	b.color = color
	b.main_node = self
	b.shot.connect(spawn_tracer)
	add_child(b)
	return b


func get_opponents(team: int) -> Array:
	var out: Array = []
	if team == 0:
		for e in enemies:
			if e.alive:
				out.append(e)
	else:
		if player.alive:
			out.append(player)
		for a in allies:
			if a.alive:
				out.append(a)
	return out


func spawn_tracer(from: Vector3, to: Vector3) -> void:
	var dist := from.distance_to(to)
	if dist < 0.5:
		return
	var m := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(0.03, 0.03, dist)
	m.mesh = box
	m.material_override = tracer_mat
	add_child(m)
	m.global_position = (from + to) * 0.5
	var dir := (to - from).normalized()
	var up := Vector3.UP if absf(dir.y) < 0.95 else Vector3.RIGHT
	m.look_at(to, up)
	get_tree().create_timer(0.05).timeout.connect(m.queue_free)


# ---------- раунды ----------

func _start_round() -> void:
	round_number += 1
	round_active = false
	player.reset_for_round(PLAYER_SPAWN)
	for i in allies.size():
		allies[i].reset_for_round(ALLY_SPAWNS[i])
	for i in enemies.size():
		enemies[i].reset_for_round(ENEMY_SPAWNS[i])
	last_hp = 100
	_update_score()
	_show_message("Раунд %d" % round_number)
	await get_tree().create_timer(2.0).timeout
	round_active = true
	_show_message("")


func _end_round(winner: int) -> void:
	round_active = false
	score[winner] += 1
	_update_score()
	var team_name := "Ваша команда (КТ)" if winner == 0 else "Противник (Т)"
	if score[winner] >= WIN_SCORE:
		_show_message("Матч окончен: победил %s\nНовый матч через несколько секунд" % team_name)
		await get_tree().create_timer(5.0).timeout
		score = [0, 0]
		round_number = 0
	else:
		_show_message("Раунд выиграл: %s" % team_name)
		await get_tree().create_timer(BETWEEN_ROUNDS).timeout
	_start_round()


# ---------- HUD ----------

func _make_label(size_px: int, align: HorizontalAlignment) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(l)
	return l


func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)

	flash_rect = ColorRect.new()
	flash_rect.color = Color(1, 0, 0, 0)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(flash_rect)
	flash_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	cross_h = ColorRect.new()
	cross_h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(cross_h)
	cross_h.set_anchors_preset(Control.PRESET_CENTER)
	cross_h.offset_left = -9
	cross_h.offset_right = 9
	cross_h.offset_top = -1
	cross_h.offset_bottom = 1

	cross_v = ColorRect.new()
	cross_v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(cross_v)
	cross_v.set_anchors_preset(Control.PRESET_CENTER)
	cross_v.offset_left = -1
	cross_v.offset_right = 1
	cross_v.offset_top = -9
	cross_v.offset_bottom = 9
	_set_cross(Color.WHITE)

	hp_label = _make_label(34, HORIZONTAL_ALIGNMENT_LEFT)
	hp_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE, Control.PRESET_MODE_MINSIZE, 24)

	ammo_label = _make_label(34, HORIZONTAL_ALIGNMENT_RIGHT)
	ammo_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE, Control.PRESET_MODE_MINSIZE, 24)

	score_label = _make_label(34, HORIZONTAL_ALIGNMENT_CENTER)
	score_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE, Control.PRESET_MODE_MINSIZE, 24)

	msg_label = _make_label(44, HORIZONTAL_ALIGNMENT_CENTER)
	msg_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	msg_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	msg_label.offset_top = -200

	if DisplayServer.is_touchscreen_available():
		var tc = TouchScript.new()
		tc.player = player
		hud.add_child(tc)

	_on_hp_changed()
	_update_ammo()


func _set_cross(c: Color) -> void:
	cross_h.color = c
	cross_v.color = c


func _show_message(text: String) -> void:
	msg_label.text = text


func _update_score() -> void:
	score_label.text = "КТ %d : %d Т   (раунд %d)" % [score[0], score[1], round_number]


func _update_ammo() -> void:
	if player.reloading:
		ammo_label.text = "Перезарядка..."
	else:
		ammo_label.text = "%d / %d" % [player.mag, player.reserve]


func _on_hp_changed() -> void:
	hp_label.text = "HP %d" % player.hp
	if player.hp < last_hp:
		flash_rect.color.a = 0.35
		var tw := create_tween()
		tw.tween_property(flash_rect, "color:a", 0.0, 0.3)
	last_hp = player.hp


func _on_player_died() -> void:
	_show_message("Вы погибли. Ждите конца раунда")


func _on_hit_enemy() -> void:
	_set_cross(Color(1, 0.2, 0.2))
	get_tree().create_timer(0.1).timeout.connect(func(): _set_cross(Color.WHITE))
