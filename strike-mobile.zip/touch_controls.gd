extends Control
# Сенсорное управление: плавающий джойстик слева, обзор свайпом справа, кнопки.

const STICK_R := 100.0
const LOOK_SENS := 0.0045
const GameSettings = preload("res://settings.gd")

var player
var ui_controls: Array = []   # элементы интерфейса (магазин): касания по ним игнорируются
var roles := {}          # индекс касания -> роль ("move", "look", "fire", "fire2", "jump", "reload")
var move_origin := Vector2.ZERO
var move_vec := Vector2.ZERO


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(_delta: float) -> void:
	queue_redraw()


func _buttons() -> Dictionary:
	var s := get_viewport_rect().size
	return {
		"fire": {"pos": Vector2(s.x - 150, s.y - 150), "r": 85.0, "label": "FIRE"},
		"fire2": {"pos": Vector2(170, s.y - 340), "r": 62.0, "label": "FIRE"},
		"jump": {"pos": Vector2(s.x - 320, s.y - 90), "r": 58.0, "label": "JUMP"},
		"reload": {"pos": Vector2(s.x - 90, s.y - 330), "r": 52.0, "label": "R"},
		"swap": {"pos": Vector2(s.x - 250, s.y - 250), "r": 46.0, "label": "SWAP"},
	}


func _input(event: InputEvent) -> void:
	if player == null:
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			_press(t.index, t.position)
		else:
			_release(t.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_drag(d.index, d.position, d.relative)


func _press(idx: int, pos: Vector2) -> void:
	for c in ui_controls:
		if c.is_visible_in_tree() and c.get_global_rect().has_point(pos):
			return
	var btns := _buttons()
	for key in btns:
		var b: Dictionary = btns[key]
		if pos.distance_to(b["pos"]) <= float(b["r"]) * 1.15:
			roles[idx] = key
			match key:
				"jump":
					player.want_jump = true
				"reload":
					player.reload()
				"swap":
					player.swap_weapon()
			_update_fire()
			return
	if pos.x < get_viewport_rect().size.x * 0.45:
		roles[idx] = "move"
		move_origin = pos
		move_vec = Vector2.ZERO
		player.touch_move = Vector2.ZERO
	else:
		roles[idx] = "look"


func _release(idx: int) -> void:
	var r: String = roles.get(idx, "")
	roles.erase(idx)
	if r == "move":
		move_vec = Vector2.ZERO
		player.touch_move = Vector2.ZERO
	_update_fire()


func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	var r: String = roles.get(idx, "")
	if r == "move":
		var v := pos - move_origin
		if v.length() > STICK_R:
			v = v.normalized() * STICK_R
		move_vec = v
		player.touch_move = Vector2(v.x, -v.y) / STICK_R
	elif r == "look" or r == "fire":
		player.look_delta += rel * LOOK_SENS * GameSettings.sensitivity


func _update_fire() -> void:
	var vals := roles.values()
	player.touch_fire = vals.has("fire") or vals.has("fire2")


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var vals := roles.values()

	# джойстик
	var s := get_viewport_rect().size
	if vals.has("move"):
		draw_circle(move_origin, STICK_R, Color(1, 1, 1, 0.12))
		draw_circle(move_origin + move_vec, 42.0, Color(1, 1, 1, 0.35))
	else:
		draw_arc(Vector2(170, s.y - 160), STICK_R * 0.8, 0.0, TAU, 40, Color(1, 1, 1, 0.2), 3.0)

	# кнопки
	var btns := _buttons()
	for key in btns:
		var b: Dictionary = btns[key]
		var active := vals.has(key)
		var p: Vector2 = b["pos"]
		var r: float = b["r"]
		draw_circle(p, r, Color(1, 1, 1, 0.35 if active else 0.15))
		draw_arc(p, r, 0.0, TAU, 40, Color(1, 1, 1, 0.5), 3.0)
		var label: String = b["label"]
		var sz := font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, 24)
		draw_string(font, p + Vector2(-sz.x / 2.0, 8.0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(1, 1, 1, 0.9))
