extends CharacterBody3D
# Игрок от первого лица. Ввод заполняет touch_controls.gd (телефон) или клавиатура/мышь (ПК).

signal hp_changed
signal ammo_changed
signal died
signal hit_enemy
signal shot(from: Vector3, to: Vector3)

const SPEED := 6.0
const JUMP_VELOCITY := 5.5
const GRAVITY := 16.0
const MAG_SIZE := 30
const FIRE_INTERVAL := 0.1
const DAMAGE := 22
const RELOAD_TIME := 1.6

var team := 0
var hp := 100
var mag := MAG_SIZE
var reserve := 90
var alive := true
var reloading := false

# ввод
var touch_move := Vector2.ZERO
var touch_fire := false
var mouse_fire := false
var want_jump := false
var look_delta := Vector2.ZERO

var yaw := 0.0
var pitch := 0.0
var fire_cd := 0.0
var reload_token := 0
var camera: Camera3D
var flash: MeshInstance3D


func _ready() -> void:
	collision_layer = 2
	collision_mask = 3

	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.4
	capsule.height = 1.8
	shape.shape = capsule
	shape.position.y = 0.9
	add_child(shape)

	camera = Camera3D.new()
	camera.position.y = 1.6
	camera.fov = 75.0
	camera.near = 0.05
	add_child(camera)
	camera.current = true

	# модель оружия
	var gun := MeshInstance3D.new()
	var gm := BoxMesh.new()
	gm.size = Vector3(0.08, 0.1, 0.5)
	gun.mesh = gm
	var gmat := StandardMaterial3D.new()
	gmat.albedo_color = Color(0.15, 0.15, 0.17)
	gun.material_override = gmat
	gun.position = Vector3(0.25, -0.22, -0.55)
	camera.add_child(gun)

	# вспышка выстрела
	flash = MeshInstance3D.new()
	var fm := BoxMesh.new()
	fm.size = Vector3(0.1, 0.1, 0.1)
	flash.mesh = fm
	var fmat := StandardMaterial3D.new()
	fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmat.albedo_color = Color(1.0, 0.85, 0.3)
	flash.material_override = fmat
	flash.position = Vector3(0.25, -0.2, -0.85)
	flash.visible = false
	camera.add_child(flash)


func _unhandled_input(event: InputEvent) -> void:
	# управление на ПК для тестов
	if event is InputEventMouseMotion:
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			look_delta += (event as InputEventMouseMotion).relative * 0.003
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
				if mb.pressed:
					Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			else:
				mouse_fire = mb.pressed
	elif event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo:
			if k.keycode == KEY_R:
				reload()
			elif k.keycode == KEY_SPACE:
				want_jump = true
			elif k.keycode == KEY_ESCAPE:
				Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
				mouse_fire = false


func _physics_process(delta: float) -> void:
	if not alive:
		return

	yaw -= look_delta.x
	pitch = clampf(pitch - look_delta.y, -1.4, 1.4)
	look_delta = Vector2.ZERO
	rotation.y = yaw
	camera.rotation.x = pitch

	var kb := Vector2.ZERO
	if Input.is_key_pressed(KEY_D):
		kb.x += 1.0
	if Input.is_key_pressed(KEY_A):
		kb.x -= 1.0
	if Input.is_key_pressed(KEY_W):
		kb.y += 1.0
	if Input.is_key_pressed(KEY_S):
		kb.y -= 1.0
	var move := touch_move + kb
	if move.length() > 1.0:
		move = move.normalized()

	var dir := global_transform.basis * Vector3(move.x, 0.0, -move.y)
	velocity.x = dir.x * SPEED
	velocity.z = dir.z * SPEED
	if is_on_floor():
		velocity.y = JUMP_VELOCITY if want_jump else 0.0
	else:
		velocity.y -= GRAVITY * delta
	want_jump = false
	move_and_slide()

	fire_cd -= delta
	if (touch_fire or mouse_fire) and fire_cd <= 0.0 and not reloading:
		_shoot()


func _shoot() -> void:
	if mag <= 0:
		reload()
		return
	mag -= 1
	fire_cd = FIRE_INTERVAL

	var origin := camera.global_position
	var cb := camera.global_transform.basis
	var dir := (-cb.z + cb.x * randf_range(-0.012, 0.012) + cb.y * randf_range(-0.012, 0.012)).normalized()
	var query := PhysicsRayQueryParameters3D.create(origin, origin + dir * 120.0)
	query.exclude = [get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)

	var end_point := origin + dir * 60.0
	if not hit.is_empty():
		end_point = hit["position"]
		var c = hit["collider"]
		if c != null and c.has_method("take_damage") and c.team != team:
			c.take_damage(DAMAGE, team)
			hit_enemy.emit()
	shot.emit(flash.global_position, end_point)

	flash.visible = true
	get_tree().create_timer(0.04).timeout.connect(func(): flash.visible = false)
	ammo_changed.emit()
	if mag == 0:
		reload()


func reload() -> void:
	if reloading or reserve <= 0 or mag >= MAG_SIZE or not alive:
		return
	reloading = true
	reload_token += 1
	var token := reload_token
	ammo_changed.emit()
	await get_tree().create_timer(RELOAD_TIME).timeout
	if token != reload_token or not alive:
		return
	var amount := mini(MAG_SIZE - mag, reserve)
	mag += amount
	reserve -= amount
	reloading = false
	ammo_changed.emit()


func take_damage(amount: int, from_team: int) -> void:
	if not alive or from_team == team:
		return
	hp = maxi(hp - amount, 0)
	hp_changed.emit()
	if hp == 0:
		alive = false
		collision_layer = 0
		touch_fire = false
		mouse_fire = false
		camera.position.y = 0.4
		camera.rotation.z = 0.5
		died.emit()


func reset_for_round(pos: Vector3) -> void:
	alive = true
	hp = 100
	mag = MAG_SIZE
	reserve = 90
	reloading = false
	reload_token += 1
	collision_layer = 2
	global_position = pos
	velocity = Vector3.ZERO
	yaw = 0.0
	pitch = 0.0
	look_delta = Vector2.ZERO
	rotation = Vector3.ZERO
	camera.position.y = 1.6
	camera.rotation = Vector3.ZERO
	hp_changed.emit()
	ammo_changed.emit()
