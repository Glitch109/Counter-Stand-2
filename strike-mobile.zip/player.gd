extends CharacterBody3D
# Игрок от первого лица. Ввод заполняет touch_controls.gd (телефон) или клавиатура/мышь (ПК).

const Weapons = preload("res://weapons.gd")

signal hp_changed
signal ammo_changed
signal died
signal hit_enemy(headshot: bool)
signal kill
signal shot(from: Vector3, to: Vector3)

const SPEED := 6.0
const JUMP_VELOCITY := 5.5
const GRAVITY := 16.0
const HEADSHOT_MULT := 2.5

var team := 0
var hp := 100
var alive := true
var reloading := false

var owned: Array = ["pistol"]   # [пистолет] или [пистолет, основное оружие]
var current := "pistol"
var ammo := {}                  # ключ оружия -> [магазин, запас]

# ввод
var touch_move := Vector2.ZERO
var touch_fire := false
var mouse_fire := false
var want_jump := false
var look_delta := Vector2.ZERO

var yaw := 0.0
var pitch := 0.0
var fire_cd := 0.0
var was_firing := false
var reload_token := 0
var camera: Camera3D
var flash: MeshInstance3D
var gun: MeshInstance3D
var gun_mesh: BoxMesh
var gun_mat: StandardMaterial3D


func _ready() -> void:
	collision_layer = 2
	collision_mask = 3

	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.4
	capsule.height = 1.8
	shape.shape = capsule
	shape.position.y = 0.9
	add_child(shape)

	camera = Camera3D.new()
	camera.position.y = 1.6
	camera.fov = 75.0
	camera.near = 0.05
	add_child(camera)
	camera.current = true

	# модель оружия
	gun = MeshInstance3D.new()
	gun_mesh = BoxMesh.new()
	gun.mesh = gun_mesh
	gun_mat = StandardMaterial3D.new()
	gun.material_override = gun_mat
	camera.add_child(gun)

	# вспышка выстрела
	flash = MeshInstance3D.new()
	var fm := BoxMesh.new()
	fm.size = Vector3(0.1, 0.1, 0.1)
	flash.mesh = fm
	var fmat := StandardMaterial3D.new()
	fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmat.albedo_color = Color(1.0, 0.85, 0.3)
	flash.material_override = fmat
	flash.visible = false
	camera.add_child(flash)

	_refill_ammo()
	_update_viewmodel()


func _refill_ammo() -> void:
	ammo.clear()
	for k in owned:
		var d: Dictionary = Weapons.DATA[k]
		ammo[k] = [d["mag"], d["reserve"]]


func _update_viewmodel() -> void:
	var d: Dictionary = Weapons.DATA[current]
	var l: float = d["len"]
	gun_mesh.size = Vector3(0.08, 0.1, l)
	gun.position = Vector3(0.25, -0.22, -(0.3 + l * 0.5))
	flash.position = Vector3(0.25, -0.2, -(0.35 + l))
	gun_mat.albedo_color = d["color"]


func get_mag() -> int:
	return ammo[current][0]


func get_reserve() -> int:
	return ammo[current][1]


func weapon_name() -> String:
	return Weapons.DATA[current]["name"]


func give_weapon(key: String) -> void:
	owned = ["pistol", key]
	var d: Dictionary = Weapons.DATA[key]
	ammo[key] = [d["mag"], d["reserve"]]
	current = key
	reload_token += 1
	reloading = false
	_update_viewmodel()
	ammo_changed.emit()


func swap_weapon() -> void:
	if owned.size() < 2 or not alive:
		return
	current = owned[0] if current != owned[0] else owned[1]
	reload_token += 1
	reloading = false
	_update_viewmodel()
	ammo_changed.emit()


func _unhandled_input(event: InputEvent) -> void:
	# управление на ПК для тестов
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo:
			if k.keycode == KEY_R:
				reload()
			elif k.keycode == KEY_SPACE:
				want_jump = true
			elif k.keycode == KEY_Q:
				swap_weapon()
			elif k.keycode == KEY_ESCAPE:
				Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
				mouse_fire = false
		return
	if DisplayServer.is_touchscreen_available():
		return  # на телефоне эмулированные касанием события мыши игнорируем
	if event is InputEventMouseMotion:
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			look_delta += (event as InputEventMouseMotion).relative * 0.003
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
				if mb.pressed:
					Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			else:
				mouse_fire = mb.pressed


func _physics_process(delta: float) -> void:
	if not alive:
		return

	yaw -= look_delta.x
	pitch = clampf(pitch - look_delta.y, -1.4, 1.4)
	look_delta = Vector2.ZERO
	rotation.y = yaw
	camera.rotation.x = pitch

	var kb := Vector2.ZERO
	if Input.is_key_pressed(KEY_D):
		kb.x += 1.0
	if Input.is_key_pressed(KEY_A):
		kb.x -= 1.0
	if Input.is_key_pressed(KEY_W):
		kb.y += 1.0
	if Input.is_key_pressed(KEY_S):
		kb.y -= 1.0
	var move := touch_move + kb
	if move.length() > 1.0:
		move = move.normalized()

	var dir := global_transform.basis * Vector3(move.x, 0.0, -move.y)
	velocity.x = dir.x * SPEED
	velocity.z = dir.z * SPEED
	if is_on_floor():
		velocity.y = JUMP_VELOCITY if want_jump else 0.0
	else:
		velocity.y -= GRAVITY * delta
	want_jump = false
	move_and_slide()

	fire_cd -= delta
	var want_fire := touch_fire or mouse_fire
	var d: Dictionary = Weapons.DATA[current]
	if want_fire and fire_cd <= 0.0 and not reloading and (d["auto"] or not was_firing):
		_shoot()
	was_firing = want_fire


func _shoot() -> void:
	var a: Array = ammo[current]
	if a[0] <= 0:
		reload()
		return
	var d: Dictionary = Weapons.DATA[current]
	a[0] -= 1
	fire_cd = d["interval"]

	# разброс растёт при движении и в прыжке
	var hv := Vector2(velocity.x, velocity.z).length() / SPEED
	var factor := 1.0 if not is_on_floor() else clampf(hv, 0.0, 1.0)
	var sp: float = float(d["spread"]) + float(d["move_spread"]) * factor

	var origin := camera.global_position
	var cb := camera.global_transform.basis
	var dir := (-cb.z + cb.x * randf_range(-sp, sp) + cb.y * randf_range(-sp, sp)).normalized()
	var query := PhysicsRayQueryParameters3D.create(origin, origin + dir * 120.0)
	query.exclude = [get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)

	var end_point := origin + dir * 60.0
	if not hit.is_empty():
		end_point = hit["position"]
		var c = hit["collider"]
		if c != null and c.has_method("take_damage") and c.team != team:
			var dmg: float = d["damage"]
			var head: bool = (hit["position"] as Vector3).y - c.global_position.y > 1.45
			if head:
				dmg *= HEADSHOT_MULT
			var was_alive: bool = c.alive
			c.take_damage(int(dmg), team)
			hit_enemy.emit(head)
			if was_alive and not c.alive:
				kill.emit()
	shot.emit(flash.global_position, end_point)

	flash.visible = true
	get_tree().create_timer(0.04).timeout.connect(func(): flash.visible = false)
	ammo_changed.emit()
	if a[0] == 0:
		reload()


func reload() -> void:
	var a: Array = ammo[current]
	var d: Dictionary = Weapons.DATA[current]
	if reloading or a[1] <= 0 or a[0] >= d["mag"] or not alive:
		return
	reloading = true
	reload_token += 1
	var token := reload_token
	ammo_changed.emit()
	await get_tree().create_timer(float(d["reload"])).timeout
	if token != reload_token or not alive:
		return
	var amount: int = mini(int(d["mag"]) - int(a[0]), int(a[1]))
	a[0] += amount
	a[1] -= amount
	reloading = false
	ammo_changed.emit()


func take_damage(amount: int, from_team: int) -> void:
	if not alive or from_team == team:
		return
	hp = maxi(hp - amount, 0)
	hp_changed.emit()
	if hp == 0:
		alive = false
		collision_layer = 0
		touch_fire = false
		mouse_fire = false
		camera.position.y = 0.4
		camera.rotation.z = 0.5
		died.emit()


func reset_for_round(pos: Vector3, keep_weapons: bool) -> void:
	alive = true
	hp = 100
	if not keep_weapons:
		owned = ["pistol"]
	current = owned[owned.size() - 1]
	_refill_ammo()
	_update_viewmodel()
	reloading = false
	reload_token += 1
	was_firing = false
	collision_layer = 2
	global_position = pos
	velocity = Vector3.ZERO
	yaw = 0.0
	pitch = 0.0
	look_delta = Vector2.ZERO
	rotation = Vector3.ZERO
	camera.position.y = 1.6
	camera.rotation = Vector3.ZERO
	hp_changed.emit()
	ammo_changed.emit()
