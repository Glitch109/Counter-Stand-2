extends RefCounted
# Карта «Пустыня»: оригинальная арена в восточном стиле из простых блоков.
# Два прохода по краям, широкий центр, две зоны с ящиками на стороне КТ.

const Models = preload("res://models.gd")

const SAND := Color(0.80, 0.70, 0.50)
const WALL := Color(0.74, 0.63, 0.46)
const WALL_DARK := Color(0.60, 0.49, 0.35)
const ROOF := Color(0.52, 0.38, 0.26)
const WOOD := Color(0.48, 0.32, 0.17)
const METAL := Color(0.30, 0.36, 0.28)
const SITE := Color(0.85, 0.45, 0.20)

# [центр, размер, цвет]
const BLOCKS = [
	# внешние стены
	[Vector3(0, 2.5, -30), Vector3(60, 5, 1), WALL_DARK],
	[Vector3(0, 2.5, 30), Vector3(60, 5, 1), WALL_DARK],
	[Vector3(-30, 2.5, 0), Vector3(1, 5, 60), WALL_DARK],
	[Vector3(30, 2.5, 0), Vector3(1, 5, 60), WALL_DARK],
	# угловые здания
	[Vector3(-21, 2, -21), Vector3(9, 4, 9), WALL],
	[Vector3(21, 2, -21), Vector3(9, 4, 9), WALL],
	[Vector3(-21, 2, 21), Vector3(9, 4, 9), WALL],
	[Vector3(21, 2, 21), Vector3(9, 4, 9), WALL],
	# центральные стены с широкими проходами
	[Vector3(-14, 1.75, 0), Vector3(12, 3.5, 1.5), WALL],
	[Vector3(14, 1.75, 0), Vector3(12, 3.5, 1.5), WALL],
	# укрытия в центре
	[Vector3(0, 1, -5), Vector3(5, 2, 1.5), WOOD],
	[Vector3(0, 1, 5), Vector3(5, 2, 1.5), WOOD],
	# укрытия перед стартовыми зонами
	[Vector3(0, 1, -18), Vector3(8, 2, 1.2), WALL],
	[Vector3(0, 1, 18), Vector3(8, 2, 1.2), WALL],
	# северные зоны с ящиками
	[Vector3(-12, 0.75, -11), Vector3(3, 1.5, 3), WOOD],
	[Vector3(-9.5, 0.75, -13), Vector3(2, 1.5, 2), WOOD],
	[Vector3(-12, 2.25, -11), Vector3(1.8, 1.5, 1.8), WOOD],
	[Vector3(-16, 1.5, -8), Vector3(1.2, 3, 6), WALL],
	[Vector3(12, 0.75, -11), Vector3(3, 1.5, 3), WOOD],
	[Vector3(9.5, 0.75, -13), Vector3(2, 1.5, 2), WOOD],
	[Vector3(12, 2.25, -11), Vector3(1.8, 1.5, 1.8), WOOD],
	[Vector3(16, 1.5, -8), Vector3(1.2, 3, 6), WALL],
	# южные зоны с ящиками (стороны А и Б)
	[Vector3(-12, 0.75, 11), Vector3(3, 1.5, 3), WOOD],
	[Vector3(-9.5, 0.75, 13), Vector3(2, 1.5, 2), WOOD],
	[Vector3(-12, 2.25, 11), Vector3(1.8, 1.5, 1.8), WOOD],
	[Vector3(-16, 1.5, 8), Vector3(1.2, 3, 6), WALL],
	[Vector3(12, 0.75, 11), Vector3(3, 1.5, 3), WOOD],
	[Vector3(9.5, 0.75, 13), Vector3(2, 1.5, 2), WOOD],
	[Vector3(12, 2.25, 11), Vector3(1.8, 1.5, 1.8), WOOD],
	[Vector3(16, 1.5, 8), Vector3(1.2, 3, 6), WALL],
]

const BARRELS = [
	Vector2(-8, -22), Vector2(8, 22), Vector2(-26, -4), Vector2(26, 4),
	Vector2(-4, 10), Vector2(4, -10), Vector2(-18, 8), Vector2(18, -8),
]

# цветные площадки зон закладки (только визуально)
const SITES = [Vector3(-12, 0.02, 12), Vector3(12, 0.02, 12)]


static func build(root: Node3D) -> void:
	Models.solid(root, Vector3(0, -0.5, 0), Vector3(60, 1, 60), SAND)
	for s in SITES:
		Models.box(root, Vector3(8, 0.04, 8), s, SITE)
	for b in BLOCKS:
		var pos: Vector3 = b[0]
		var size: Vector3 = b[1]
		var color: Color = b[2]
		Models.solid(root, pos, size, color)
		if size.y >= 3.5 and size.x < 50.0 and size.z < 50.0:
			# карниз на высоких стенах
			Models.box(root, Vector3(size.x + 0.3, 0.3, size.z + 0.3), pos + Vector3(0, size.y * 0.5 + 0.15, 0), ROOF)
	for p in BARRELS:
		Models.solid_cylinder(root, Vector3(p.x, 0.55, p.y), 0.45, 1.1, METAL)
