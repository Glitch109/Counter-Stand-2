extends Node3D
# Главное меню: 3D-фон с вращающимся солдатом, кнопки, настройки.

const Models = preload("res://models.gd")
const GameSettings = preload("res://settings.gd")

const ACCENT := Color(1.0, 0.45, 0.2)
const QUALITY_NAMES = ["Низкая", "Средняя", "Высокая"]

var soldier: Node3D
var main_box: VBoxContainer
var settings_box: VBoxContainer
var sens_label: Label


func _ready() -> void:
	GameSettings.load_settings()
	Engine.max_fps = 60
	_build_scene()
	_build_ui()


func _process(delta: float) -> void:
	if soldier != null:
		soldier.rotation.y += delta * 0.6


func _build_scene() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.07, 0.08, 0.11)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.45, 0.48, 0.58)
	env.ambient_light_energy = 0.8
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var key_light := DirectionalLight3D.new()
	key_light.rotation_degrees = Vector3(-30, 30, 0)
	key_light.light_color = Color(1.0, 0.9, 0.8)
	key_light.light_energy = 1.1
	add_child(key_light)

	var rim := DirectionalLight3D.new()
	rim.rotation_degrees = Vector3(-20, 200, 0)
	rim.light_color = Color(0.4, 0.55, 1.0)
	rim.light_energy = 0.8
	add_child(rim)

	var cam := Camera3D.new()
	cam.fov = 60.0
	add_child(cam)
	cam.look_at_from_position(Vector3(0, 1.25, 3.6), Vector3(-1.2, 1.0, 0))
	cam.current = true

	Models.cyl(self, 1.4, 0.1, Vector3(0.9, -0.05, 0), Color(0.15, 0.16, 0.2))
	soldier = Models.make_soldier(Color(0.2, 0.45, 0.95))
	soldier.position = Vector3(0.9, 0, 0)
	add_child(soldier)


func _style_button(b: Button) -> void:
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.12, 0.14, 0.18, 0.9)
	normal.set_corner_radius_all(8)
	normal.border_width_left = 6
	normal.border_color = Color(0.3, 0.33, 0.4)
	normal.content_margin_left = 24
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(0.18, 0.2, 0.26, 0.95)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(0.25, 0.14, 0.08, 0.95)
	pressed.border_color = ACCENT
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_font_size_override("font_size", 34)
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT


func _make_button(text: String, callback: Callable, min_w := 420.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(min_w, 84)
	_style_button(b)
	b.pressed.connect(callback)
	return b


func _make_label(text: String, size_px: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", color)
	return l


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# главное меню
	main_box = VBoxContainer.new()
	main_box.add_theme_constant_override("separation", 16)
	main_box.position = Vector2(70, 80)
	root.add_child(main_box)
	main_box.add_child(_make_label("STRIKE MOBILE", 64, Color.WHITE))
	main_box.add_child(_make_label("Тактический шутер  •  Карта: Пустыня", 24, Color(0.7, 0.74, 0.8)))
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 20)
	main_box.add_child(spacer)
	main_box.add_child(_make_button("ИГРАТЬ", _on_play))
	main_box.add_child(_make_button("НАСТРОЙКИ", _on_settings))
	main_box.add_child(_make_button("ВЫХОД", func(): get_tree().quit()))

	# настройки
	settings_box = VBoxContainer.new()
	settings_box.add_theme_constant_override("separation", 14)
	settings_box.position = Vector2(70, 60)
	settings_box.visible = false
	root.add_child(settings_box)
	settings_box.add_child(_make_label("НАСТРОЙКИ", 52, Color.WHITE))
	settings_box.add_child(_make_label("Графика", 28, Color(0.7, 0.74, 0.8)))

	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	settings_box.add_child(hb)
	var group := ButtonGroup.new()
	for i in QUALITY_NAMES.size():
		var qb := _make_button(QUALITY_NAMES[i], _set_quality.bind(i), 190.0)
		qb.custom_minimum_size = Vector2(190, 76)
		qb.add_theme_font_size_override("font_size", 28)
		qb.toggle_mode = true
		qb.button_group = group
		qb.button_pressed = (i == GameSettings.quality)
		hb.add_child(qb)

	sens_label = _make_label("", 28, Color(0.7, 0.74, 0.8))
	settings_box.add_child(sens_label)
	var slider := HSlider.new()
	slider.min_value = 0.5
	slider.max_value = 2.0
	slider.step = 0.05
	slider.value = GameSettings.sensitivity
	slider.custom_minimum_size = Vector2(620, 50)
	slider.value_changed.connect(_on_sensitivity)
	settings_box.add_child(slider)
	_on_sensitivity(slider.value)

	settings_box.add_child(_make_label("Низкая графика даёт больше FPS на слабых телефонах.", 22, Color(0.55, 0.58, 0.65)))
	settings_box.add_child(_make_button("НАЗАД", _on_back))


func _on_play() -> void:
	get_tree().change_scene_to_file("res://main.tscn")


func _on_settings() -> void:
	main_box.visible = false
	settings_box.visible = true


func _on_back() -> void:
	GameSettings.save_settings()
	settings_box.visible = false
	main_box.visible = true


func _set_quality(i: int) -> void:
	GameSettings.quality = i


func _on_sensitivity(v: float) -> void:
	GameSettings.sensitivity = v
	sens_label.text = "Чувствительность обзора: %.2f" % v


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if settings_box != null and settings_box.visible:
			_on_back()
		else:
			get_tree().quit()
